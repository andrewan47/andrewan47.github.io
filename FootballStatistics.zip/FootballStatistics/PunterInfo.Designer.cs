﻿namespace FootballStatistics
{
    partial class PunterInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.yardsReturned = new System.Windows.Forms.TextBox();
            this.puntRating = new System.Windows.Forms.TextBox();
            this.punts = new System.Windows.Forms.TextBox();
            this.yards = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.TextBox();
            this.position = new System.Windows.Forms.TextBox();
            this.save = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.yardsTotal = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.saveEdit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // yardsReturned
            // 
            this.yardsReturned.Location = new System.Drawing.Point(24, 172);
            this.yardsReturned.Name = "yardsReturned";
            this.yardsReturned.Size = new System.Drawing.Size(100, 20);
            this.yardsReturned.TabIndex = 0;
            // 
            // puntRating
            // 
            this.puntRating.Location = new System.Drawing.Point(174, 172);
            this.puntRating.Name = "puntRating";
            this.puntRating.ReadOnly = true;
            this.puntRating.Size = new System.Drawing.Size(100, 20);
            this.puntRating.TabIndex = 1;
            // 
            // punts
            // 
            this.punts.Location = new System.Drawing.Point(24, 107);
            this.punts.Name = "punts";
            this.punts.Size = new System.Drawing.Size(100, 20);
            this.punts.TabIndex = 2;
            // 
            // yards
            // 
            this.yards.Location = new System.Drawing.Point(174, 107);
            this.yards.Name = "yards";
            this.yards.Size = new System.Drawing.Size(100, 20);
            this.yards.TabIndex = 3;
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(24, 35);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(100, 20);
            this.name.TabIndex = 4;
            // 
            // position
            // 
            this.position.Location = new System.Drawing.Point(174, 35);
            this.position.Name = "position";
            this.position.ReadOnly = true;
            this.position.Size = new System.Drawing.Size(100, 20);
            this.position.TabIndex = 5;
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(49, 215);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(75, 23);
            this.save.TabIndex = 6;
            this.save.Text = "Save";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(174, 215);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 7;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(171, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Position";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Punts";
            // 
            // yardsTotal
            // 
            this.yardsTotal.AutoSize = true;
            this.yardsTotal.Location = new System.Drawing.Point(171, 91);
            this.yardsTotal.Name = "yardsTotal";
            this.yardsTotal.Size = new System.Drawing.Size(61, 13);
            this.yardsTotal.TabIndex = 11;
            this.yardsTotal.Text = "Total Yards";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 156);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Total Yards Returned";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(171, 156);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Punt Rating";
            // 
            // saveEdit
            // 
            this.saveEdit.Location = new System.Drawing.Point(49, 215);
            this.saveEdit.Name = "saveEdit";
            this.saveEdit.Size = new System.Drawing.Size(75, 23);
            this.saveEdit.TabIndex = 14;
            this.saveEdit.Text = "Save Edit";
            this.saveEdit.UseVisualStyleBackColor = true;
            this.saveEdit.Visible = false;
            this.saveEdit.Click += new System.EventHandler(this.saveEdit_Click);
            // 
            // PunterInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 250);
            this.Controls.Add(this.saveEdit);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.yardsTotal);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.save);
            this.Controls.Add(this.position);
            this.Controls.Add(this.name);
            this.Controls.Add(this.yards);
            this.Controls.Add(this.punts);
            this.Controls.Add(this.puntRating);
            this.Controls.Add(this.yardsReturned);
            this.Name = "PunterInfo";
            this.Text = "PunterInfo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox yardsReturned;
        private System.Windows.Forms.TextBox puntRating;
        private System.Windows.Forms.TextBox punts;
        private System.Windows.Forms.TextBox yards;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.TextBox position;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label yardsTotal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button saveEdit;
    }
}