﻿namespace FootballStatistics
{
    partial class WR_TE_Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.name = new System.Windows.Forms.TextBox();
            this.position = new System.Windows.Forms.TextBox();
            this.attempts = new System.Windows.Forms.TextBox();
            this.receptions = new System.Windows.Forms.TextBox();
            this.yards = new System.Windows.Forms.TextBox();
            this.touchdowns = new System.Windows.Forms.TextBox();
            this.fumbles = new System.Windows.Forms.TextBox();
            this.receptionRating = new System.Windows.Forms.TextBox();
            this.save = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.saveEdit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(49, 59);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(100, 20);
            this.name.TabIndex = 0;
            // 
            // position
            // 
            this.position.Location = new System.Drawing.Point(235, 59);
            this.position.Name = "position";
            this.position.ReadOnly = true;
            this.position.Size = new System.Drawing.Size(100, 20);
            this.position.TabIndex = 1;
            // 
            // attempts
            // 
            this.attempts.Location = new System.Drawing.Point(49, 122);
            this.attempts.Name = "attempts";
            this.attempts.Size = new System.Drawing.Size(100, 20);
            this.attempts.TabIndex = 2;
            // 
            // receptions
            // 
            this.receptions.Location = new System.Drawing.Point(235, 122);
            this.receptions.Name = "receptions";
            this.receptions.Size = new System.Drawing.Size(100, 20);
            this.receptions.TabIndex = 3;
            // 
            // yards
            // 
            this.yards.Location = new System.Drawing.Point(49, 193);
            this.yards.Name = "yards";
            this.yards.Size = new System.Drawing.Size(100, 20);
            this.yards.TabIndex = 4;
            // 
            // touchdowns
            // 
            this.touchdowns.Location = new System.Drawing.Point(235, 193);
            this.touchdowns.Name = "touchdowns";
            this.touchdowns.Size = new System.Drawing.Size(100, 20);
            this.touchdowns.TabIndex = 5;
            // 
            // fumbles
            // 
            this.fumbles.Location = new System.Drawing.Point(49, 257);
            this.fumbles.Name = "fumbles";
            this.fumbles.Size = new System.Drawing.Size(100, 20);
            this.fumbles.TabIndex = 6;
            // 
            // receptionRating
            // 
            this.receptionRating.Location = new System.Drawing.Point(235, 257);
            this.receptionRating.Name = "receptionRating";
            this.receptionRating.ReadOnly = true;
            this.receptionRating.Size = new System.Drawing.Size(100, 20);
            this.receptionRating.TabIndex = 7;
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(74, 307);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(75, 23);
            this.save.TabIndex = 8;
            this.save.Text = "Save";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(235, 307);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 9;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(232, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Position";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Attempts";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(232, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Receptions";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(46, 177);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Total Yards";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(232, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Touchdowns";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(46, 241);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Fumbles";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(232, 241);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Reception Rating";
            // 
            // saveEdit
            // 
            this.saveEdit.Location = new System.Drawing.Point(74, 307);
            this.saveEdit.Name = "saveEdit";
            this.saveEdit.Size = new System.Drawing.Size(75, 23);
            this.saveEdit.TabIndex = 18;
            this.saveEdit.Text = "Save Edit";
            this.saveEdit.UseVisualStyleBackColor = true;
            this.saveEdit.Visible = false;
            this.saveEdit.Click += new System.EventHandler(this.saveEdit_Click);
            // 
            // WR_TE_Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 342);
            this.Controls.Add(this.saveEdit);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.save);
            this.Controls.Add(this.receptionRating);
            this.Controls.Add(this.fumbles);
            this.Controls.Add(this.touchdowns);
            this.Controls.Add(this.yards);
            this.Controls.Add(this.receptions);
            this.Controls.Add(this.attempts);
            this.Controls.Add(this.position);
            this.Controls.Add(this.name);
            this.Name = "WR_TE_Info";
            this.Text = "WR_TE_Info";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.TextBox position;
        private System.Windows.Forms.TextBox attempts;
        private System.Windows.Forms.TextBox receptions;
        private System.Windows.Forms.TextBox yards;
        private System.Windows.Forms.TextBox touchdowns;
        private System.Windows.Forms.TextBox fumbles;
        private System.Windows.Forms.TextBox receptionRating;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button saveEdit;
    }
}