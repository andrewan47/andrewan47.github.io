﻿namespace FootballStatistics
{
    partial class QBInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.save = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.passingRating = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.TextBox();
            this.passAttempts = new System.Windows.Forms.TextBox();
            this.passingYards = new System.Windows.Forms.TextBox();
            this.passCompletions = new System.Windows.Forms.TextBox();
            this.interceptions = new System.Windows.Forms.TextBox();
            this.passingTD = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.position = new System.Windows.Forms.TextBox();
            this.saveEdit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(47, 292);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(75, 23);
            this.save.TabIndex = 0;
            this.save.Text = "Save";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(182, 292);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 1;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // passingRating
            // 
            this.passingRating.Location = new System.Drawing.Point(182, 231);
            this.passingRating.Name = "passingRating";
            this.passingRating.ReadOnly = true;
            this.passingRating.Size = new System.Drawing.Size(100, 20);
            this.passingRating.TabIndex = 2;
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(22, 21);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(100, 20);
            this.name.TabIndex = 3;
            // 
            // passAttempts
            // 
            this.passAttempts.Location = new System.Drawing.Point(22, 86);
            this.passAttempts.Name = "passAttempts";
            this.passAttempts.Size = new System.Drawing.Size(100, 20);
            this.passAttempts.TabIndex = 4;
            // 
            // passingYards
            // 
            this.passingYards.Location = new System.Drawing.Point(182, 86);
            this.passingYards.Name = "passingYards";
            this.passingYards.Size = new System.Drawing.Size(100, 20);
            this.passingYards.TabIndex = 5;
            // 
            // passCompletions
            // 
            this.passCompletions.Location = new System.Drawing.Point(22, 154);
            this.passCompletions.Name = "passCompletions";
            this.passCompletions.Size = new System.Drawing.Size(100, 20);
            this.passCompletions.TabIndex = 6;
            // 
            // interceptions
            // 
            this.interceptions.Location = new System.Drawing.Point(22, 231);
            this.interceptions.Name = "interceptions";
            this.interceptions.Size = new System.Drawing.Size(100, 20);
            this.interceptions.TabIndex = 7;
            // 
            // passingTD
            // 
            this.passingTD.Location = new System.Drawing.Point(180, 154);
            this.passingTD.Name = "passingTD";
            this.passingTD.Size = new System.Drawing.Size(100, 20);
            this.passingTD.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Pass Attempts";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(179, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Total Passing Yards";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Pass Completions";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 215);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Interceptions";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(179, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Passing Touchdowns";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(179, 215);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Passing Rating";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(179, 5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Position";
            // 
            // position
            // 
            this.position.Location = new System.Drawing.Point(182, 21);
            this.position.Name = "position";
            this.position.ReadOnly = true;
            this.position.Size = new System.Drawing.Size(100, 20);
            this.position.TabIndex = 17;
            // 
            // saveEdit
            // 
            this.saveEdit.Location = new System.Drawing.Point(47, 292);
            this.saveEdit.Name = "saveEdit";
            this.saveEdit.Size = new System.Drawing.Size(75, 23);
            this.saveEdit.TabIndex = 18;
            this.saveEdit.Text = "Save Edit";
            this.saveEdit.UseVisualStyleBackColor = true;
            this.saveEdit.Visible = false;
            this.saveEdit.Click += new System.EventHandler(this.saveEdit_Click);
            // 
            // QBInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(337, 327);
            this.Controls.Add(this.saveEdit);
            this.Controls.Add(this.position);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.passingTD);
            this.Controls.Add(this.interceptions);
            this.Controls.Add(this.passCompletions);
            this.Controls.Add(this.passingYards);
            this.Controls.Add(this.passAttempts);
            this.Controls.Add(this.name);
            this.Controls.Add(this.passingRating);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.save);
            this.Name = "QBInfo";
            this.Text = "QBInfo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button save;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.TextBox passingRating;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.TextBox passAttempts;
        private System.Windows.Forms.TextBox passingYards;
        private System.Windows.Forms.TextBox passCompletions;
        private System.Windows.Forms.TextBox interceptions;
        private System.Windows.Forms.TextBox passingTD;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox position;
        private System.Windows.Forms.Button saveEdit;
    }
}