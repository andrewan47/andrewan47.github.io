﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FootballStatistics
{
    public partial class KickerInfo : Form
    {
        public string invalid = "";
        string fileFirst;
        string fileLast;
        public KickerInfo()
        {
            InitializeComponent();
            position.Text = Form1.position;
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void save_Click(object sender, EventArgs e)
        {
            int n = checkN();
            string pos = position.Text;
            int fga = checkFGA();
            int fgm = checkFGM(fga);
            double l = checkL(fgm);
            int epa = checkEPA();
            int epm = checkEPM(epa);
            if (n != -1 && fga != -1 && fgm != -1 && l != -1 && epa != -1 && epm != -1)
            {
                string[] player = name.Text.Split();
                double kr = rating(fgm, l, fga, epm, epa);
                Kicker k = new Kicker(player[0], player[1], pos, fga, fgm, l, epa, epm, kr);
                Form1.fbk = k;
                Form1.k_list.Add(Form1.fbk);
                try
                {
                    StreamWriter outputFile;
                    outputFile = File.AppendText("stats.txt");
                    outputFile.WriteLine(pos + ' ' + player[0] + ' ' + player[1] + ' ' + fga + ' ' + fgm + ' ' + l + ' ' + epa + ' ' + epm + ' ' + kr);
                    outputFile.Close();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show(invalid);
                invalid = "";
            }
        }
        public int checkN()
        {
            if (name.Text == String.Empty)
            {
                invalid += "Please enter a name.\n";
                return -1;
            }
            string[] n = name.Text.Split();
            if (n.Length != 2)
            {
                invalid += "Please enter First and Last name only.\n";
                return -1;
            }
            for (int x = 0; x < Form1.k_list.Count; x++)
            {
                string compare = (string)Form1.k_list[x].First.ToString() + " " + (string)Form1.k_list[x].Last.ToString();
                if (compare.Equals(name.Text, StringComparison.InvariantCultureIgnoreCase))
                {
                    invalid += "There is already a player with this same name.\n";
                    return -1;
                }
            }
            return 1;
        }
        private int checkN(int i)
        {
            if (name.Text == String.Empty)
            {
                invalid += "Please enter a name.\n";
                return -1;
            }
            string[] n = name.Text.Split();
            if (n.Length != 2)
            {
                invalid += "Please enter First and Last name only.\n";
                return -1;
            }
            for (int x = 0; x < Form1.k_list.Count; x++)
            {
                if (i != x)
                {
                    string compare = (string)Form1.k_list[x].First.ToString() + " " + (string)Form1.k_list[x].Last.ToString();
                    if (compare.Equals(name.Text, StringComparison.InvariantCultureIgnoreCase))
                    {
                        invalid += "There is already a player with this same name.\n";
                        return -1;
                    }
                }
            }
            return 1;
        }
        public int checkFGA()
        {
            int fga;
            bool check = Int32.TryParse(FGAttempts.Text, out fga);
            if (check)
            {
                if (fga < 0)
                {
                    invalid += "Please enter a positive number of Field Goal Attempts.\n";
                    return -1;
                }
                else
                    return fga;
            }
            else
            {
                invalid += "Please enter a valid number for Field Goal Attempts.\n";
                return -1;
            }
        }
        public int checkFGM(int fga)
        {
            int fgm;
            bool check = Int32.TryParse(fieldGoals.Text, out fgm);
            if (check)
            {
                if (fgm < 0)
                {
                    invalid += "Please enter a positive number of Fiel Goals.";
                    return -1;
                }
                else if (fgm > fga)
                {
                    invalid += "Field Goals Made cannot be higher than Field Goal Attempts.\n";
                    return -1;
                }
                else
                    return fgm;
            }
            else
            {
                invalid += "Please enter a valid number of Field Goals Made.\n";
                return -1;
            }
        }
        public double checkL(int fga)
        {
            double l;
            bool check = double.TryParse(longest.Text, out l);
            if (check)
            {
                if (l < 0)
                {
                    invalid += "Longest Field Goal cannot be a negative number.\n";
                    return -1;
                }
                else if (l > 0 && fga == 0)
                {
                    invalid += "Cannot have a longest Field Goal if player has never made one.\n";
                    return -1;
                }
                else
                    return l;
            }
            else
            {
                invalid += "Please enter a valid number for Longest Field Goal.\n";
                return -1;
            }
        }
        public int checkEPA()
        {
            int epa;
            bool check = Int32.TryParse(EPAttempts.Text, out epa);
            if (check)
            {
                if (epa < 0)
                {
                    invalid += "Cannot have negative number of Extra Points Attempts.\n";
                    return -1;
                }
                else
                    return epa;
            }
            else
            {
                invalid += "Please enter a valid number for Extra Points Attempts.\n";
                return -1;
            }
        }
        public int checkEPM(int epa)
        {
            int epm;
            bool check = Int32.TryParse(extraPoints.Text, out epm);
            if (check)
            {
                if (epm < 0)
                {
                    invalid += "Cannot have a negative number of Extra Points Made.\n";
                    return -1;
                }
                else if (epm > epa)
                {
                    invalid += "Extra Points cannot exceed the number of attempts.\n";
                    return -1;
                }
                else
                    return epm;
            }
            else
            {
                invalid += "Please enter a valid number of Extra Points.\n";
                return -1;
            }
        }
        public double rating(int fgm, double l, int fga, int epm, int epa)
        {
            double kr = (((200 * fgm) + (0.5 * l)) / fga) + (50 * epm / epa);
            return kr;
        }
        public void displayKicker()
        {
            string first = (string)Form1.k_list[Form1.index].First.ToString();
            string last = (string)Form1.k_list[Form1.index].Last.ToString();
            string n = first + ' ' + last;
            name.Text = n;
            position.Text = (string)Form1.k_list[Form1.index].position.ToString();
            FGAttempts.Text = (string)Form1.k_list[Form1.index].FieldGoalAttempts.ToString();
            fieldGoals.Text = (string)Form1.k_list[Form1.index].FieldGoalsMade.ToString();
            longest.Text = (string)Form1.k_list[Form1.index].Longest.ToString();
            EPAttempts.Text = (string)Form1.k_list[Form1.index].ExtraPointsAttempts.ToString();
            extraPoints.Text = (string)Form1.k_list[Form1.index].ExtraPointsMade.ToString();
            kickerRating.Text = (string)Form1.k_list[Form1.index].ExtraPointsMade.ToString();
            name.ReadOnly = true;
            FGAttempts.ReadOnly = true;
            fieldGoals.ReadOnly = true;
            longest.ReadOnly = true;
            EPAttempts.ReadOnly = true;
            extraPoints.ReadOnly = true;
            save.Visible = false;
        }

        public void editK()
        {
            save.Visible = false;
            saveEdit.Visible = true;
            fileFirst = (string)Form1.k_list[Form1.index].First.ToString();
            fileLast = (string)Form1.k_list[Form1.index].Last.ToString();
            string n = fileFirst + ' ' + fileLast;
            name.Text = n;
            position.Text = (string)Form1.k_list[Form1.index].position.ToString();
            FGAttempts.Text = (string)Form1.k_list[Form1.index].FieldGoalAttempts.ToString();
            fieldGoals.Text = (string)Form1.k_list[Form1.index].FieldGoalsMade.ToString();
            longest.Text = (string)Form1.k_list[Form1.index].Longest.ToString();
            EPAttempts.Text = (string)Form1.k_list[Form1.index].ExtraPointsAttempts.ToString();
            extraPoints.Text = (string)Form1.k_list[Form1.index].ExtraPointsMade.ToString();
        }

        private void saveEdit_Click(object sender, EventArgs e)
        {
            int n = checkN(Form1.index);
            string pos = position.Text;
            int fga = checkFGA();
            int fgm = checkFGM(fga);
            double l = checkL(fgm);
            int epa = checkEPA();
            int epm = checkEPM(epa);
            if (n != -1 && fga != -1 && fgm != -1 && l != -1 && epa != -1 && epm != -1)
            {
                string[] player = name.Text.Split();
                double kr = rating(fgm, l, fga, epm, epa);
                Form1.k_list[Form1.index].First = player[0];
                Form1.k_list[Form1.index].Last = player[1];
                Form1.k_list[Form1.index].FieldGoalAttempts = fga;
                Form1.k_list[Form1.index].FieldGoalsMade = fgm;
                Form1.k_list[Form1.index].Longest = l;
                Form1.k_list[Form1.index].ExtraPointsAttempts = epa;
                Form1.k_list[Form1.index].ExtraPointsMade = epm;
                Form1.k_list[Form1.index].KickerRating = kr;
                pos = "Kicker";
                string input = pos + " " + player[0] + " " + player[1] + " " + fga + " " + fgm + " " + l + " " + epa + " " + epm + " " + kr;
                int count = 0;
                string line;
                string[] str;
                try
                {
                    StreamReader inputFile;
                    inputFile = File.OpenText("stats.txt");
                    while (!inputFile.EndOfStream)
                    {
                        line = inputFile.ReadLine();
                        if (line != String.Empty)
                        {
                            str = line.Split(' ');
                            if (fileFirst == str[1] && fileLast == str[2] && pos == str[0])
                            {
                                break;
                            }
                            else
                                count++;
                        }
                        else
                            count++;
                    }
                    inputFile.Close();
                    line = File.ReadLines("stats.txt").Skip(count).Take(1).First();
                    var x = File.ReadAllLines("stats.txt");
                    x[count] = input;
                    File.WriteAllLines("stats.txt", x);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show(invalid);
                invalid = "";
            }
        }
    }

    public class Kicker : FootballPlayer
    {
        private int m_FieldGoalAttempts;
        private int m_FieldGoalsMade;
        private double m_Longest;
        private int m_ExtraPointsAttempts;
        private int m_ExtraPointsMade;
        private double m_KickerRating;

        public int FieldGoalAttempts
        {
            get { return m_FieldGoalAttempts; }
            set { m_FieldGoalAttempts = value; }
        }
        public int FieldGoalsMade
        {
            get { return m_FieldGoalsMade; }
            set { m_FieldGoalsMade = value; }
        }
        public double Longest
        {
            get { return m_Longest; }
            set { m_Longest = value; }
        }
        public int ExtraPointsAttempts
        {
            get { return m_ExtraPointsAttempts; }
            set { m_ExtraPointsAttempts = value; }
        }
        public int ExtraPointsMade
        {
            get { return m_ExtraPointsMade; }
            set { m_ExtraPointsMade = value; }
        }
        public double KickerRating
        {
            get { return m_KickerRating; }
            set { m_KickerRating = value; }
        }
        public Kicker(string first, string last, string position, int fga,
            int fgm, double l, int epa, int epm, double kr) : base(first, last, position)
        {
            m_FieldGoalAttempts = fga;
            m_FieldGoalsMade = fgm;
            m_Longest = l;
            m_ExtraPointsAttempts = epa;
            m_ExtraPointsMade = epm;
            m_KickerRating = kr;
        }
    }
}