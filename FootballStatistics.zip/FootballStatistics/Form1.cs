﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FootballStatistics
{
    public partial class Form1 : Form
    {
        public static List<QuarterBack> qb_list = new List<QuarterBack>();
        public static QuarterBack fbqb;
        public static List<RunningBack> rb_list = new List<RunningBack>();
        public static RunningBack fbrb;
        public static List<TightEnd_WideRecieve> te_list = new List<TightEnd_WideRecieve>();
        public static TightEnd_WideRecieve fbte;
        public static List<TightEnd_WideRecieve> wr_list = new List<TightEnd_WideRecieve>();
        public static TightEnd_WideRecieve fbwr;
        public static List<Punts> p_list = new List<Punts>();
        public static Punts fbp;
        public static List<Kicker> k_list = new List<Kicker>();
        public static Kicker fbk;
        public static string position;
        public static int index;
        public Form1()
        {
            InitializeComponent();
            positionBox.Items.Add("Quarterback");
            positionBox.Items.Add("Running Back");
            positionBox.Items.Add("Wide Receiver");
            positionBox.Items.Add("Tight End");
            positionBox.Items.Add("Punter");
            positionBox.Items.Add("Kicker");
            loadFile();
        }

        private void add_Click(object sender, EventArgs e)
        {
            position = (string)positionBox.SelectedItem;

            if (positionBox.SelectedItem == null)
                MessageBox.Show("Please selected a position for the new football player.");
            else if (position == "Quarterback")
            {
                QBInfo qb = new QBInfo();
                qb.Show();

                List<string> full_qb = new List<string>();
                foreach (QuarterBack pl in qb_list)
                {
                    full_qb.Add(pl.First);
                    full_qb.Add(pl.Last);
                    full_qb.Add(pl.position);
                    full_qb.Add(pl.PassAttempts.ToString());
                    full_qb.Add(pl.PassCompletions.ToString());
                }
                dataGridView1.DataSource = qb_list.ToArray();
                dataGridView1.Refresh();
            }
            else if (position == "Running Back")
            {
                RBInfo rb = new RBInfo();
                rb.Show();

                List<string> full_rb = new List<string>();
                foreach (RunningBack pl in rb_list)
                {
                    full_rb.Add(pl.First);
                }
                dataGridView1.DataSource = rb_list.ToArray();
                dataGridView1.Refresh();
            }
            else if (position == "Tight End")
            {
                WR_TE_Info te = new WR_TE_Info();
                te.Show();

                List<string> full_te = new List<string>();
                foreach (TightEnd_WideRecieve pl in te_list)
                {
                    full_te.Add(pl.First);
                }
                dataGridView1.DataSource = te_list.ToArray();
                dataGridView1.Refresh();
            }
            else if (position == "Wide Receiver")
            {
                WR_TE_Info wr = new WR_TE_Info();
                wr.Show();

                List<string> full_wr = new List<string>();
                foreach (TightEnd_WideRecieve pl in wr_list)
                {
                    full_wr.Add(pl.First);
                }
                dataGridView1.DataSource = wr_list.ToArray();
                dataGridView1.Refresh();
            }
            else if (position == "Punter")
            {
                PunterInfo p = new PunterInfo();
                p.Show();

                List<string> full_p = new List<string>();
                foreach (Punts pl in p_list)
                {
                    full_p.Add(pl.First);
                }
                dataGridView1.DataSource = p_list.ToArray();
                dataGridView1.Refresh();
            }
            else if (position == "Kicker")
            {
                KickerInfo k = new KickerInfo();
                k.Show();

                List<string> full_k = new List<string>();
                foreach (Kicker pl in k_list)
                {
                    full_k.Add(pl.First);
                }
                dataGridView1.DataSource = k_list.ToArray();
                dataGridView1.Refresh();
            }
            positionBox_SelectedIndexChanged(sender, e);
        }

        private void loadFile()
        {
            string line;
            string[] str;
            try
            {
                StreamReader inputFile;
                inputFile = File.OpenText("stats.txt");
                while (!inputFile.EndOfStream)
                {
                    line = inputFile.ReadLine();
                    if (line != String.Empty)
                    {
                        str = line.Split(' ');
                        string position = str[0] + ' ' + str[1];
                        if (str[0] == "Quarterback")
                        {
                            int pa = Int32.Parse(str[3]);
                            int pc = Int32.Parse(str[4]);
                            double py = double.Parse(str[5]);
                            int ptd = Int32.Parse(str[6]);
                            int i = Int32.Parse(str[7]);
                            double r = double.Parse(str[8]);
                            QuarterBack qb = new QuarterBack(str[1], str[2], str[0], pa, pc, py, ptd, i, r);
                            fbqb = qb;
                            qb_list.Add(fbqb);
                        }
                        else if (position == "Running Back")
                        {
                            int c = Int32.Parse(str[4]);
                            double ry = double.Parse(str[5]);
                            int td = Int32.Parse(str[6]);
                            int f = Int32.Parse(str[7]);
                            double r = double.Parse(str[8]);
                            RunningBack rb = new RunningBack(str[2], str[3], position, c, ry, td, f, r);
                            fbrb = rb;
                            rb_list.Add(fbrb);
                        }
                        else if (position == "Tight End")
                        {
                            int a = Int32.Parse(str[4]);
                            int r = Int32.Parse(str[5]);
                            double ty = double.Parse(str[6]);
                            int td = Int32.Parse(str[7]);
                            int f = Int32.Parse(str[8]);
                            double rr = double.Parse(str[9]);
                            TightEnd_WideRecieve te = new TightEnd_WideRecieve(str[2], str[3], position, a, r, ty, td, f, rr);
                            fbte = te;
                            te_list.Add(fbte);
                        }
                        else if (position == "Wide Receiver")
                        {
                            int a = Int32.Parse(str[4]);
                            int r = Int32.Parse(str[5]);
                            double ty = double.Parse(str[6]);
                            int td = Int32.Parse(str[7]);
                            int f = Int32.Parse(str[8]);
                            double rr = double.Parse(str[9]);
                            TightEnd_WideRecieve wr = new TightEnd_WideRecieve(str[2], str[3], position, a, r, ty, td, f, rr);
                            fbwr = wr;
                            wr_list.Add(fbwr);
                        }
                        else if (str[0] == "Punter")
                        {
                            int p = Int32.Parse(str[3]);
                            double ty = double.Parse(str[4]);
                            double tyr = double.Parse(str[5]);
                            double r = double.Parse(str[6]);
                            Punts pu = new Punts(str[1], str[2], str[0], p, ty, tyr, r);
                            fbp = pu;
                            p_list.Add(fbp);
                        }
                        else if (str[0] == "Kicker")
                        {
                            int fga = Int32.Parse(str[3]);
                            int fgm = Int32.Parse(str[4]);
                            double l = double.Parse(str[5]);
                            int epa = Int32.Parse(str[6]);
                            int epm = Int32.Parse(str[7]);
                            double r = double.Parse(str[8]);
                            Kicker kik = new Kicker(str[1], str[2], str[0], fga, fgm, l, epa, epm, r);
                            fbk = kik;
                            k_list.Add(fbk);
                        }
                    }
                }
                inputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void positionBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((string)positionBox.SelectedItem == "Quarterback")
            {
                try
                {
                    dataGridView1.DataSource = qb_list.ToArray();
                }
                catch (System.ArgumentOutOfRangeException ex)
                {

                }
            }
            else if ((string)positionBox.SelectedItem == "Running Back")
            {
                try
                {
                    dataGridView1.DataSource = rb_list.ToArray();
                }
                catch (System.ArgumentOutOfRangeException ex)
                {

                }
            }
            else if ((string)positionBox.SelectedItem == "Wide Receiver")
            {
                try
                {
                    dataGridView1.DataSource = wr_list.ToArray();
                }
                catch (System.ArgumentOutOfRangeException ex) { }
            }
            else if ((string)positionBox.SelectedItem == "Tight End")
            {
                try
                {
                    dataGridView1.DataSource = te_list.ToArray();
                }
                catch (System.ArgumentOutOfRangeException ex) { }
            }
            else if ((string)positionBox.SelectedItem == "Punter")
            {
                try
                {
                    dataGridView1.DataSource = p_list.ToArray();
                }
                catch (System.ArgumentOutOfRangeException ex) { }
            }
            else if ((string)positionBox.SelectedItem == "Kicker")
            {
                try
                {
                    dataGridView1.DataSource = k_list.ToArray();
                }
                catch (System.ArgumentOutOfRangeException ex) { }
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            try {
                index = dataGridView1.CurrentCell.RowIndex;
                if ((string)positionBox.SelectedItem == "Quarterback")
                {
                    string first = (string)qb_list[index].First.ToString();
                    string last = (string)qb_list[index].Last.ToString();
                    string pos = "Quarterback";
                    string delete = null;
                    int count = 0;
                    string line;
                    string[] str;
                    try
                    {
                        StreamReader inputFile;
                        inputFile = File.OpenText("stats.txt");
                        while (!inputFile.EndOfStream)
                        {
                            line = inputFile.ReadLine();
                            if (line != String.Empty)
                            {
                                str = line.Split(' ');
                                if (first == str[1] && last == str[2] && pos == str[0])
                                {
                                    break;
                                }
                                else
                                    count++;
                            }
                            else
                                count++;
                        }
                        inputFile.Close();
                        line = File.ReadLines("stats.txt").Skip(count).Take(1).First();
                        var x = File.ReadAllLines("stats.txt");
                        x[count] = delete;
                        File.WriteAllLines("stats.txt", x);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    qb_list.RemoveAt(index);
                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = qb_list;
                    dataGridView1.Refresh();
                }
                else if ((string)positionBox.SelectedItem == "Running Back")
                {
                    string first = (string)rb_list[index].First.ToString();
                    string last = (string)rb_list[index].Last.ToString();
                    string pos = "Running Back";
                    string delete = null;
                    int count = 0;
                    string line;
                    string[] str;
                    try
                    {
                        StreamReader inputFile;
                        inputFile = File.OpenText("stats.txt");
                        while (!inputFile.EndOfStream)
                        {
                            line = inputFile.ReadLine();
                            if (line != String.Empty)
                            {
                                str = line.Split(' ');
                                string pos_file = str[0] + ' ' + str[1];
                                if (first == str[2] && last == str[3] && pos == pos_file)
                                {
                                    break;
                                }
                                else
                                    count++;
                            }
                            else
                                count++;
                        }
                        inputFile.Close();
                        line = File.ReadLines("stats.txt").Skip(count).Take(1).First();
                        var x = File.ReadAllLines("stats.txt");
                        x[count] = delete;
                        File.WriteAllLines("stats.txt", x);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    rb_list.RemoveAt(index);
                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = rb_list;
                    dataGridView1.Refresh();
                }
                else if ((string)positionBox.SelectedItem == "Wide Receiver")
                {
                    string first = (string)wr_list[index].First.ToString();
                    string last = (string)wr_list[index].Last.ToString();
                    string pos = "Wide Receiver";
                    string delete = null;
                    int count = 0;
                    string line;
                    string[] str;
                    try
                    {
                        StreamReader inputFile;
                        inputFile = File.OpenText("stats.txt");
                        while (!inputFile.EndOfStream)
                        {
                            line = inputFile.ReadLine();
                            if (line != String.Empty)
                            {
                                str = line.Split(' ');
                                string pos_file = str[0] + ' ' + str[1];
                                if (first == str[2] && last == str[3] && pos == pos_file)
                                {
                                    break;
                                }
                                else
                                    count++;
                            }
                            else
                                count++;
                        }
                        inputFile.Close();
                        line = File.ReadLines("stats.txt").Skip(count).Take(1).First();
                        var x = File.ReadAllLines("stats.txt");
                        x[count] = delete;
                        File.WriteAllLines("stats.txt", x);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    wr_list.RemoveAt(index);
                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = wr_list;
                    dataGridView1.Refresh();
                }
                else if ((string)positionBox.SelectedItem == "Tight End")
                {
                    string first = (string)te_list[index].First.ToString();
                    string last = (string)te_list[index].Last.ToString();
                    string pos = "Tight End";
                    string delete = null;
                    int count = 0;
                    string line;
                    string[] str;
                    try
                    {
                        StreamReader inputFile;
                        inputFile = File.OpenText("stats.txt");
                        while (!inputFile.EndOfStream)
                        {
                            line = inputFile.ReadLine();
                            if (line != String.Empty)
                            {
                                str = line.Split(' ');
                                string pos_file = str[0] + ' ' + str[1];
                                if (first == str[2] && last == str[3] && pos == pos_file)
                                {
                                    break;
                                }
                                else
                                    count++;
                            }
                            else
                                count++;
                        }
                        inputFile.Close();
                        line = File.ReadLines("stats.txt").Skip(count).Take(1).First();
                        var x = File.ReadAllLines("stats.txt");
                        x[count] = delete;
                        File.WriteAllLines("stats.txt", x);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    te_list.RemoveAt(index);
                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = te_list;
                    dataGridView1.Refresh();
                }
                else if ((string)positionBox.SelectedItem == "Punter")
                {
                    string first = (string)p_list[index].First.ToString();
                    string last = (string)p_list[index].Last.ToString();
                    string pos = "Punter";
                    string delete = null;
                    int count = 0;
                    string line;
                    string[] str;
                    try
                    {
                        StreamReader inputFile;
                        inputFile = File.OpenText("stats.txt");
                        while (!inputFile.EndOfStream)
                        {
                            line = inputFile.ReadLine();
                            if (line != String.Empty)
                            {
                                str = line.Split(' ');
                                if (first == str[1] && last == str[2] && pos == str[0])
                                {
                                    break;
                                }
                                else
                                    count++;
                            }
                            else
                                count++;
                        }
                        inputFile.Close();
                        line = File.ReadLines("stats.txt").Skip(count).Take(1).First();
                        var x = File.ReadAllLines("stats.txt");
                        x[count] = delete;
                        File.WriteAllLines("stats.txt", x);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    p_list.RemoveAt(index);
                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = p_list;
                    dataGridView1.Refresh();
                }
                else if ((string)positionBox.SelectedItem == "Kicker")
                {
                    string first = (string)k_list[index].First.ToString();
                    string last = (string)k_list[index].Last.ToString();
                    string pos = "Kicker";
                    string delete = null;
                    int count = 0;
                    string line;
                    string[] str;
                    try
                    {
                        StreamReader inputFile;
                        inputFile = File.OpenText("stats.txt");
                        while (!inputFile.EndOfStream)
                        {
                            line = inputFile.ReadLine();
                            if (line != String.Empty)
                            {
                                str = line.Split(' ');
                                if (first == str[1] && last == str[2] && pos == str[0])
                                {
                                    break;
                                }
                                else
                                    count++;
                            }
                            else
                                count++;
                        }
                        inputFile.Close();
                        line = File.ReadLines("stats.txt").Skip(count).Take(1).First();
                        var x = File.ReadAllLines("stats.txt");
                        x[count] = delete;
                        File.WriteAllLines("stats.txt", x);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    k_list.RemoveAt(index);
                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = k_list;
                    dataGridView1.Refresh();
                }
            }
            catch (NullReferenceException ex)
            {

            }
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            index = dataGridView1.CurrentCell.RowIndex;
            if ((string)positionBox.SelectedItem == "Quarterback")
            {
                QBInfo qbi = new QBInfo();
                qbi.displayQB();
                qbi.Show();
            }
            else if ((string)positionBox.SelectedItem == "Running Back")
            {
                RBInfo rbi = new RBInfo();
                rbi.displayRB();
                rbi.Show();
            }
            else if ((string)positionBox.SelectedItem == "Tight End")
            {
                WR_TE_Info tei = new WR_TE_Info();
                tei.displayTE();
                tei.Show();
            }
            else if ((string)positionBox.SelectedItem == "Wide Receiver")
            {
                WR_TE_Info wri = new WR_TE_Info();
                wri.displayWR();
                wri.Show();
            }
            else if ((string)positionBox.SelectedItem == "Punter")
            {
                PunterInfo pi = new PunterInfo();
                pi.displayPunter();
                pi.Show();
            }
            else if ((string)positionBox.SelectedItem == "Kicker")
            {
                KickerInfo ki = new KickerInfo();
                ki.displayKicker();
                ki.Show();
            }
        }

        private void edit_Click(object sender, EventArgs e)
        {
            index = dataGridView1.CurrentCell.RowIndex;
            if ((string)positionBox.SelectedItem == "Quarterback")
            {
                QBInfo qbe = new QBInfo();
                qbe.editQB();
                qbe.Show();
            }
            else if ((string)positionBox.SelectedItem == "Tight End")
            {
                WR_TE_Info tee = new WR_TE_Info();
                tee.editTE();
                tee.Show();
            }
            else if ((string)positionBox.SelectedItem == "Wide Receiver")
            {
                WR_TE_Info wre = new WR_TE_Info();
                wre.editWR();
                wre.Show();
            }
            else if ((string)positionBox.SelectedItem == "Running Back")
            {
                RBInfo rbe = new RBInfo();
                rbe.editRB();
                rbe.Show();
            }
            else if ((string)positionBox.SelectedItem == "Punter")
            {
                PunterInfo pe = new PunterInfo();
                pe.editP();
                pe.Show();
            }
            else if ((string)positionBox.SelectedItem == "Kicker")
            {
                KickerInfo ke = new KickerInfo();
                ke.editK();
                ke.Show();
            }
        }

        private void dataGridView1_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int col = e.ColumnIndex;
            if ((string)positionBox.SelectedItem == "Quarterback")
            {
                if (col == 0)
                    qb_list.Sort(delegate (QuarterBack c1, QuarterBack c2) { return c2.PassAttempts.CompareTo(c1.PassAttempts); });
                else if (col == 1)
                    qb_list.Sort(delegate (QuarterBack c1, QuarterBack c2) { return c2.PassCompletions.CompareTo(c1.PassCompletions); });
                else if (col == 2)
                    qb_list.Sort(delegate (QuarterBack c1, QuarterBack c2) { return c2.PassingYards.CompareTo(c1.PassingYards); });
                else if (col == 3)
                    qb_list.Sort(delegate (QuarterBack c1, QuarterBack c2) { return c2.PassingTouchdowns.CompareTo(c1.PassingTouchdowns); });
                else if (col == 4)
                    qb_list.Sort(delegate (QuarterBack c1, QuarterBack c2) { return c2.Interceptions.CompareTo(c1.Interceptions); });
                else if (col == 5)
                    qb_list.Sort(delegate (QuarterBack c1, QuarterBack c2) { return c2.PassingRating.CompareTo(c1.PassingRating); });
                else if (col == 6)
                    qb_list.Sort(CompareFirst);
                else if (col == 7)
                    qb_list.Sort(CompareLast);
                dataGridView1.DataSource = qb_list.ToArray();
            }
            else if ((string)positionBox.SelectedItem == "Running Back")
            {
                if (col == 0)
                    rb_list.Sort(delegate (RunningBack c1, RunningBack c2) { return c2.Carries.CompareTo(c1.Carries); });
                else if (col == 1)
                    rb_list.Sort(delegate (RunningBack c1, RunningBack c2) { return c2.RushingYards.CompareTo(c1.RushingYards); });
                else if (col == 2)
                    rb_list.Sort(delegate (RunningBack c1, RunningBack c2) { return c2.Touchdowns.CompareTo(c1.Touchdowns); });
                else if (col == 3)
                    rb_list.Sort(delegate (RunningBack c1, RunningBack c2) { return c2.Fumbles.CompareTo(c1.Fumbles); });
                else if (col == 4)
                    rb_list.Sort(delegate (RunningBack c1, RunningBack c2) { return c2.RushingRating.CompareTo(c1.RushingRating); });
                else if (col == 5)
                    rb_list.Sort(CompareFirst);
                else if (col == 6)
                    rb_list.Sort(CompareLast);
                dataGridView1.DataSource = rb_list.ToArray();
            }
            else if ((string)positionBox.SelectedItem == "Tight End")
            {
                if (col == 0)
                    te_list.Sort(delegate (TightEnd_WideRecieve c1, TightEnd_WideRecieve c2) { return c2.Attempts.CompareTo(c1.Attempts); });
                else if (col == 1)
                    te_list.Sort(delegate (TightEnd_WideRecieve c1, TightEnd_WideRecieve c2) { return c2.Receptions.CompareTo(c1.Receptions); });
                else if (col == 2)
                    te_list.Sort(delegate (TightEnd_WideRecieve c1, TightEnd_WideRecieve c2) { return c2.TotalYards.CompareTo(c1.TotalYards); });
                else if (col == 3)
                    te_list.Sort(delegate (TightEnd_WideRecieve c1, TightEnd_WideRecieve c2) { return c2.Touchdowns.CompareTo(c1.Touchdowns); });
                else if (col == 4)
                    te_list.Sort(delegate (TightEnd_WideRecieve c1, TightEnd_WideRecieve c2) { return c2.Fumbles.CompareTo(c1.Fumbles); });
                else if (col == 5)
                    te_list.Sort(delegate (TightEnd_WideRecieve c1, TightEnd_WideRecieve c2) { return c2.ReceptionRating.CompareTo(c1.ReceptionRating); });
                else if (col == 6)
                    te_list.Sort(CompareFirst);
                else if (col == 7)
                    te_list.Sort(CompareLast);
                dataGridView1.DataSource = te_list.ToArray();
            }
            else if ((string)positionBox.SelectedItem == "Wide Receiver")
            {
                if (col == 0)
                    wr_list.Sort(delegate (TightEnd_WideRecieve c1, TightEnd_WideRecieve c2) { return c2.Attempts.CompareTo(c1.Attempts); });
                else if (col == 1)
                    wr_list.Sort(delegate (TightEnd_WideRecieve c1, TightEnd_WideRecieve c2) { return c2.Receptions.CompareTo(c1.Receptions); });
                else if (col == 2)
                    wr_list.Sort(delegate (TightEnd_WideRecieve c1, TightEnd_WideRecieve c2) { return c2.TotalYards.CompareTo(c1.TotalYards); });
                else if (col == 3)
                    wr_list.Sort(delegate (TightEnd_WideRecieve c1, TightEnd_WideRecieve c2) { return c2.Touchdowns.CompareTo(c1.Touchdowns); });
                else if (col == 4)
                    wr_list.Sort(delegate (TightEnd_WideRecieve c1, TightEnd_WideRecieve c2) { return c2.Fumbles.CompareTo(c1.Fumbles); });
                else if (col == 5)
                    wr_list.Sort(delegate (TightEnd_WideRecieve c1, TightEnd_WideRecieve c2) { return c2.ReceptionRating.CompareTo(c1.ReceptionRating); });
                if (col == 6)
                    wr_list.Sort(CompareFirst);
                else if (col == 7)
                    wr_list.Sort(CompareLast);
                dataGridView1.DataSource = wr_list.ToArray();
            }
            else if ((string)positionBox.SelectedItem == "Punter")
            {
                if (col == 0)
                    p_list.Sort(delegate (Punts c1, Punts c2) { return c2.Punt.CompareTo(c1.Punt); });
                else if (col == 1)
                    p_list.Sort(delegate (Punts c1, Punts c2) { return c2.TotalYards.CompareTo(c1.TotalYards); });
                else if (col == 2)
                    p_list.Sort(delegate (Punts c1, Punts c2) { return c2.ReturningYards.CompareTo(c1.ReturningYards); });
                else if (col == 3)
                    p_list.Sort(delegate (Punts c1, Punts c2) { return c2.PuntRating.CompareTo(c1.PuntRating); });
                else if (col == 4)
                    p_list.Sort(CompareFirst);
                else if (col == 5)
                    p_list.Sort(CompareLast);
                dataGridView1.DataSource = p_list.ToArray();
            }
            else if ((string)positionBox.SelectedItem == "Kicker")
            {
                if (col == 0)
                    k_list.Sort(delegate (Kicker c1, Kicker c2) { return c2.FieldGoalAttempts.CompareTo(c1.FieldGoalAttempts); });
                else if (col == 1)
                    k_list.Sort(delegate (Kicker c1, Kicker c2) { return c2.FieldGoalsMade.CompareTo(c1.FieldGoalsMade); });
                else if (col == 2)
                    k_list.Sort(delegate (Kicker c1, Kicker c2) { return c2.Longest.CompareTo(c1.Longest); });
                else if (col == 3)
                    k_list.Sort(delegate (Kicker c1, Kicker c2) { return c2.ExtraPointsAttempts.CompareTo(c1.ExtraPointsAttempts); });
                else if (col == 4)
                    k_list.Sort(delegate (Kicker c1, Kicker c2) { return c2.ExtraPointsMade.CompareTo(c1.ExtraPointsMade); });
                else if (col == 5)
                    k_list.Sort(delegate (Kicker c1, Kicker c2) { return c2.KickerRating.CompareTo(c1.KickerRating); });
                else if (col == 6)
                    k_list.Sort(CompareFirst);
                else if (col == 7)
                    k_list.Sort(CompareLast);
                dataGridView1.DataSource = k_list.ToArray();
            }
        }

        private static int CompareFirst(FootballPlayer firstx, FootballPlayer firsty)
        {
            string x = firstx.First;
            string y = firsty.First;
            return x.CompareTo(y);
        }
        private static int CompareLast(FootballPlayer lastx, FootballPlayer lasty)
        {
            string x = lastx.Last;
            string y = lasty.Last;
            return x.CompareTo(y);
        }
    }

    public class FootballPlayer
    {
        private string m_First;
        private string m_Last;
        private string m_Position;

        public string First
        {
            get { return m_First; }
            set { m_First = value; }
        }
        public string Last
        {
            get { return m_Last; }
            set { m_Last = value; }
        }
        public string position
        {
            get { return m_Position; }
            set { m_Position = value; }
        }
        public FootballPlayer(string first, string last, string position)
        {
            m_First = first;
            m_Last = last;
            m_Position = position;
        }
        public FootballPlayer()
        {
        }
    }
}