﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FootballStatistics
{
    public partial class QBInfo : Form
    {

        string invalid = "";
        string fileFirst;
        string fileLast;
        public QBInfo()
        {
            InitializeComponent();
            position.Text = Form1.position;
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void save_Click(object sender, EventArgs e)
        {
            string pos = position.Text;
            int n = checkN();
            int pa = checkPA();
            int pc = checkPC(pa);
            double py = checkPY(pc);
            int ptd = checkPTD(pc, pa);
            int i = checkI(pa);

            if (n != -1 && pa != -1 && pc != -1 && py != -1 && ptd != -1 && i != -1)
            {
                string[] player = name.Text.Split();
                double pr = rating(py, ptd, pc, i, pa);
                QuarterBack qb = new QuarterBack(player[0], player[1], pos, pa, pc, py, ptd, i, pr);
                Form1.fbqb = qb;
                Form1.qb_list.Add(Form1.fbqb);
                try
                {
                    StreamWriter outputFile;
                    outputFile = File.AppendText("stats.txt");
                    outputFile.WriteLine(pos + ' ' + player[0] + ' ' + player[1] + ' ' + pa + ' ' + pc + ' ' + py + ' ' + ptd + ' ' + i + ' ' + pr);
                    outputFile.Close();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show(invalid);
                invalid = "";
            }
        }
        public int checkN()
        {
            if (name.Text == String.Empty)
            {
                invalid += "Please enter a name.\n";
                return -1;
            }
            string[] n = name.Text.Split();
            if (n.Length != 2)
            {
                invalid += "Please enter First and Last name only.\n";
                return -1;
            }
            for (int x = 0; x < Form1.qb_list.Count; x++)
            {
                string compare = (string)Form1.qb_list[x].First.ToString() + " " + (string)Form1.qb_list[x].Last.ToString();
                if (compare.Equals(name.Text, StringComparison.InvariantCultureIgnoreCase))
                {
                    invalid += "There is already a player with this same name.\n";
                    return -1;
                }
            }
            return 1;
        }
        public int checkN(int i)
        {
            if (name.Text == String.Empty)
            {
                invalid += "Please enter a name.\n";
                return -1;
            }
            string[] n = name.Text.Split();
            if (n.Length != 2)
            {
                invalid += "Please enter First and Last name only.\n";
                return -1;
            }
            for (int x = 0; x < Form1.qb_list.Count; x++)
            {
                if (i != x)
                {
                    string compare = (string)Form1.qb_list[x].First.ToString() + " " + (string)Form1.qb_list[x].Last.ToString();
                    if (compare.Equals(name.Text, StringComparison.InvariantCultureIgnoreCase))
                    {
                        invalid += "There is already a player with this same name.\n";
                        return -1;
                    }
                }
            }
            return 1;
        }
        public int checkPA()
        {
            int pa;
            bool check = Int32.TryParse(passAttempts.Text, out pa);
            if (check)
            {
                if (pa >= 0)
                    return pa;
                else
                {
                    invalid += "Please enter a positive number for Passing Attempts.\n";
                    return -1;
                }
            }
            else
            {
                invalid += "Please enter a valid number for Passing Attempts.\n";
                return -1;
            }
        }
        public int checkPC(int pa)
        {
            int pc;
            bool check = Int32.TryParse(passCompletions.Text, out pc);
            if (check)
            {
                if (pc < 0)
                {
                    invalid += "Please enter a positive number for Pass Completions.\n";
                    return -1;
                }
                else if (pc > pa)
                {
                    invalid += "Pass Completions cannot greater than Pass Attempts.\n";
                    return -1;
                }
                else
                    return pc;
            }
            else
            {
                invalid += "Please enter a valid number for Pass Completions.\n";
                return -1;
            }
        }
        public double checkPY(int pc)
        {
            double py;
            bool check = Double.TryParse(passingYards.Text, out py);
            if (check)
            {
                if (py < 0)
                {
                    invalid += "Passing Yards cannot be a negative number.\n";
                    return -1;
                }
                else if (pc > 0 && py == 0)
                {
                    invalid += "Passing Yards cannot be zero if there was a completed pass.\n";
                    return -1;
                }
                else
                    return py;
            }
            else
            {
                invalid += "Please enter a valid number for Passing Yards.\n";
                return -1;
            }
        }
        public int checkPTD(int pc, int pa)
        {
            int ptd;
            bool check = Int32.TryParse(passingTD.Text, out ptd);
            if (check)
            {
                if (ptd < 0)
                {
                    invalid += "Passing Touchdown cannot be a negative number.\n";
                    return -1;
                }
                else if (ptd > pc)
                {
                    invalid += "Passing Touchdowns cannot be greater than pass completions.\n";
                    return -1;
                }
                else if (ptd > pa)
                {
                    invalid += "Passing Touchdowns cannot be greater than passing attempts.\n";
                    return -1;
                }
                else
                    return ptd;
            }
            else
            {
                invalid += "Please enter a valid number for Passing Touchdowns.\n";
                return -1;
            }
        }
        public int checkI(int pa)
        {
            int i;
            bool check = Int32.TryParse(interceptions.Text, out i);
            if (check)
            {
                if (i < 0)
                {
                    invalid += "Please enter a positive number for Interceptions.\n";
                    return -1;
                }
                else if (i > pa)
                {
                    invalid += "Interceptions cannot be greater than pass attempts.\n";
                    return -1;
                }
                else
                    return i;
            }
            else
            {
                invalid += "Please enter a valid number for Interceptions.\n";
                return -1;
            }
        }
        public double rating(double py, int ptd, int pc, int i, int pa)
        {
            double pr = ((8.4 * py) + (330 * ptd) + (100 * pc) - (200 * i)) / pa;
            return pr;
        }
        public void displayQB()
        {
            string first = (string)Form1.qb_list[Form1.index].First.ToString();
            string last = (string)Form1.qb_list[Form1.index].Last.ToString();
            string n = first + ' ' + last;
            name.Text = n;
            position.Text = (string)Form1.qb_list[Form1.index].position.ToString();
            passAttempts.Text = (string)Form1.qb_list[Form1.index].PassAttempts.ToString();
            passingYards.Text = (string)Form1.qb_list[Form1.index].PassingYards.ToString();
            passCompletions.Text = (string)Form1.qb_list[Form1.index].PassCompletions.ToString();
            passingTD.Text = (string)Form1.qb_list[Form1.index].PassingTouchdowns.ToString();
            interceptions.Text = (string)Form1.qb_list[Form1.index].Interceptions.ToString();
            passingRating.Text = (string)Form1.qb_list[Form1.index].PassingRating.ToString();
            name.ReadOnly = true;
            passAttempts.ReadOnly = true;
            passingYards.ReadOnly = true;
            passCompletions.ReadOnly = true;
            passingTD.ReadOnly = true;
            interceptions.ReadOnly = true;
            save.Visible = false;
        }
        public void editQB()
        {
            save.Visible = false;
            saveEdit.Visible = true;
            fileFirst = (string)Form1.qb_list[Form1.index].First.ToString();
            fileLast = (string)Form1.qb_list[Form1.index].Last.ToString();
            string n = fileFirst + ' ' + fileLast;
            name.Text = n;
            position.Text = (string)Form1.qb_list[Form1.index].position.ToString();
            passAttempts.Text = (string)Form1.qb_list[Form1.index].PassAttempts.ToString();
            passingYards.Text = (string)Form1.qb_list[Form1.index].PassingYards.ToString();
            passCompletions.Text = (string)Form1.qb_list[Form1.index].PassCompletions.ToString();
            passingTD.Text = (string)Form1.qb_list[Form1.index].PassingTouchdowns.ToString();
            interceptions.Text = (string)Form1.qb_list[Form1.index].Interceptions.ToString();
            passingRating.Text = (string)Form1.qb_list[Form1.index].PassingRating.ToString();
        }

        private void saveEdit_Click(object sender, EventArgs e)
        {
            string pos = position.Text;
            int n = checkN(Form1.index);
            int pa = checkPA();
            int pc = checkPC(pa);
            double py = checkPY(pc);
            int ptd = checkPTD(pc, pa);
            int i = checkI(pa);

            if (n != -1 && pa != -1 && pc != -1 && py != -1 && ptd != -1 && i != -1)
            {
                string[] player = name.Text.Split();
                double pr = rating(py, ptd, pc, i, pa);
                Form1.qb_list[Form1.index].First = player[0];
                Form1.qb_list[Form1.index].Last = player[1];
                Form1.qb_list[Form1.index].PassAttempts = pa;
                Form1.qb_list[Form1.index].PassCompletions = pc;
                Form1.qb_list[Form1.index].PassingYards = py;
                Form1.qb_list[Form1.index].PassingTouchdowns = ptd;
                Form1.qb_list[Form1.index].Interceptions = i;
                Form1.qb_list[Form1.index].PassingRating = pr;
                pos = "Quarterback";
                string input = pos + " " + player[0] + " " + player[1] + " " + pa + " " + pc + " " + py + " " + ptd + " " + i + " " + pr;
                int count = 0;
                string line;
                string[] str;
                try
                {
                    StreamReader inputFile;
                    inputFile = File.OpenText("stats.txt");
                    while (!inputFile.EndOfStream)
                    {
                        line = inputFile.ReadLine();
                        if (line != String.Empty)
                        {
                            str = line.Split(' ');
                            if (fileFirst == str[1] && fileLast == str[2] && pos == str[0])
                            {
                                break;
                            }
                            else
                                count++;
                        }
                        else
                            count++;
                    }
                    inputFile.Close();
                    line = File.ReadLines("stats.txt").Skip(count).Take(1).First();
                    var x = File.ReadAllLines("stats.txt");
                    x[count] = input;
                    File.WriteAllLines("stats.txt", x);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show(invalid);
                invalid = "";
            }
        }
    }

    public class QuarterBack : FootballPlayer
    {
        private int m_PassAttempts;
        private int m_PassCompletions;
        private double m_PassingYards;
        private int m_PassingTouchdowns;
        private int m_Interceptions;
        private double m_PassingRating;

        public int PassAttempts
        {
            get { return m_PassAttempts; }
            set { m_PassAttempts = value; }
        }
        public int PassCompletions
        {
            get { return m_PassCompletions; }
            set { m_PassCompletions = value; }
        }
        public double PassingYards
        {
            get { return m_PassingYards; }
            set { m_PassingYards = value; }
        }
        public int PassingTouchdowns
        {
            get { return m_PassingTouchdowns; }
            set { m_PassingTouchdowns = value; }
        }
        public int Interceptions
        {
            get { return m_Interceptions; }
            set { m_Interceptions = value; }
        }
        public double PassingRating
        {
            get { return m_PassingRating; }
            set { m_PassingRating = value; }
        }
        public QuarterBack(string first, string last, string position, int passAttempt, int passComp, double passYards, int passTD, int interceptions, double pr) : base (first, last, position)
        {
            m_PassAttempts = passAttempt;
            m_PassCompletions = passComp;
            m_PassingYards = passYards;
            m_PassingTouchdowns = passTD;
            m_Interceptions = interceptions;
            m_PassingRating = pr;
        }
    }
}