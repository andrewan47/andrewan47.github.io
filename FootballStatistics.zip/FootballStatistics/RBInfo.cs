﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FootballStatistics
{
    public partial class RBInfo : Form
    {
        string invalid = "";
        string fileFirst;
        string fileLast;
        public RBInfo()
        {
            InitializeComponent();
            position.Text = Form1.position;
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void save_Click(object sender, EventArgs e)
        {
            int n = checkN();
            string pos = position.Text;
            int c = checkC();
            double ry = checkRY(c);
            int td = checkTD(c);
            int f = checkF(c);
            if (n != -1 && c != -1 && ry != -1 && td != -1 && f != -1)
            {
                string[] player = name.Text.Split();
                double rr = rating(ry, td, f, c);
                RunningBack rb = new RunningBack(player[0], player[1], pos, c, ry, td, f, rr);
                Form1.fbrb = rb;
                Form1.rb_list.Add(Form1.fbrb);
                try
                {
                    StreamWriter outputFile;
                    outputFile = File.AppendText("stats.txt");
                    outputFile.WriteLine(pos + ' ' + player[0] + ' ' + player[1] + ' ' + c + ' ' + ry + ' ' + td + ' ' + f + ' ' + rr);
                    outputFile.Close();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
                MessageBox.Show(invalid);
        }
        private int checkN()
        {
            if (name.Text == String.Empty)
            {
                invalid += "Please enter a name.\n";
                return -1;
            }
            string[] n = name.Text.Split();
            if (n.Length != 2)
            {
                invalid += "Please enter First and Last name only.\n";
                return -1;
            }
            for (int x = 0; x < Form1.rb_list.Count; x++)
            {
                string compare = (string)Form1.rb_list[x].First.ToString() + " " + (string)Form1.rb_list[x].Last.ToString();
                if (compare.Equals(name.Text, StringComparison.InvariantCultureIgnoreCase))
                {
                    invalid += "There is already a player with this same name.\n";
                    return -1;
                }
            }
            return 1;
        }
        public int checkN(int i)
        {
            if (name.Text == String.Empty)
            {
                invalid += "Please enter a name.\n";
                return -1;
            }
            string[] n = name.Text.Split();
            if (n.Length != 2)
            {
                invalid += "Please enter First and Last name only.\n";
                return -1;
            }
            for (int x = 0; x < Form1.rb_list.Count; x++)
            {
                if (i != x)
                {
                    string compare = (string)Form1.rb_list[x].First.ToString() + " " + (string)Form1.rb_list[x].Last.ToString();
                    if (compare.Equals(name.Text, StringComparison.InvariantCultureIgnoreCase))
                    {
                        invalid += "There is already a player with this same name.\n";
                        return -1;
                    }
                }
            }
            return 1;
        }
        public int checkC()
        {
            int c;
            bool check = Int32.TryParse(carries.Text, out c);
            if (check)
            {
                if (c >= 0)
                    return c;
                else
                {
                    invalid += "Please enter a positive number for number of Carries.\n";
                    return -1;
                }
            }
            else
            {
                invalid += "Enter right number of Carries.\n";
                return -1;
            }
        }
        public double checkRY(int c)
        {
            double ry;
            bool check = double.TryParse(rushingYards.Text, out ry);
            if (check)
            {
                if (ry < 0)
                {
                    invalid += "Cannot have a negative number of Yards.\n";
                    return -1;
                }
                else if (ry > 0 && c == 0)
                {
                    invalid += "Cannot have Yards if was never handed the ball.\n";
                    return -1;
                }
                else
                    return ry;
            }
            else
            {
                invalid += "Please enter number of Rushing Yards.\n";
                return -1;
            }
        }
        public int checkTD(int c)
        {
            int td;
            bool check = Int32.TryParse(touchdowns.Text, out td);
            if (check)
            {
                if (td < 0)
                {
                    invalid += "Cannot have a negative number of Touchdowns.\n";
                    return -1;
                }
                else if (td > 0 && c == 0)
                {
                    invalid += "Cannot have scored a touchdown if they were never given the ball.\n";
                    return -1;
                }
                else
                    return td;
            }
            else
            {
                invalid += "Please enter number for touchdowns.\n";
                return -1;
            }
        }
        public int checkF(int c)
        {
            int f;
            bool check = Int32.TryParse(fumbles.Text, out f);
            if (check)
            {
                if (f < 0)
                {
                    invalid += "Cannot have a negative number of Fumbles.\n";
                    return -1;
                }
                else if (f > 0 && c == 0)
                {
                    invalid += "Could not have fumbled the ball if they were never given the ball.\n";
                    return -1;
                }
                else
                    return f;
            }
            else
            {
                invalid += "Please enter number for fumbles.\n";
                return -1;
            }
        }
        public double rating(double ry, int td, int f, int c)
        {
            double rr = ((25 * ry) + (330 * td) - (200 * f)) / c;
            return rr;
        }
        public void displayRB()
        {
            string first = (string)Form1.rb_list[Form1.index].First.ToString();
            string last = (string)Form1.rb_list[Form1.index].Last.ToString();
            string n = first + ' ' + last;
            name.Text = n;
            position.Text = (string)Form1.rb_list[Form1.index].position.ToString();
            carries.Text = (string)Form1.rb_list[Form1.index].Carries.ToString();
            rushingYards.Text = (string)Form1.rb_list[Form1.index].RushingYards.ToString();
            touchdowns.Text = (string)Form1.rb_list[Form1.index].Touchdowns.ToString();
            fumbles.Text = (string)Form1.rb_list[Form1.index].Fumbles.ToString();
            rushingRating.Text = (string)Form1.rb_list[Form1.index].RushingRating.ToString();
            name.ReadOnly = true;
            carries.ReadOnly = true;
            rushingYards.ReadOnly = true;
            touchdowns.ReadOnly = true;
            fumbles.ReadOnly = true;
            save.Visible = false;
        }
        public void editRB()
        {
            save.Visible = false;
            saveEdit.Visible = true;
            fileFirst = (string)Form1.rb_list[Form1.index].First.ToString();
            fileLast = (string)Form1.rb_list[Form1.index].Last.ToString();
            string n = fileFirst + ' ' + fileLast;
            name.Text = n;
            position.Text = (string)Form1.rb_list[Form1.index].position.ToString();
            carries.Text = (string)Form1.rb_list[Form1.index].Carries.ToString();
            rushingYards.Text = (string)Form1.rb_list[Form1.index].RushingYards.ToString();
            touchdowns.Text = (string)Form1.rb_list[Form1.index].Touchdowns.ToString();
            fumbles.Text = (string)Form1.rb_list[Form1.index].Fumbles.ToString();
            rushingRating.Text = (string)Form1.rb_list[Form1.index].RushingRating.ToString();
        }

        private void saveEdit_Click(object sender, EventArgs e)
        {
            int n = checkN(Form1.index);
            string pos = position.Text;
            int c = checkC();
            double ry = checkRY(c);
            int td = checkTD(c);
            int f = checkF(c);
            if (n != -1 && c != -1 && ry != -1 && td != -1 && f != -1)
            {
                string[] player = name.Text.Split();
                double rr = rating(ry, td, f, c);
                Form1.rb_list[Form1.index].First = player[0];
                Form1.rb_list[Form1.index].Last = player[1];
                Form1.rb_list[Form1.index].Carries = c;
                Form1.rb_list[Form1.index].RushingYards = ry;
                Form1.rb_list[Form1.index].Touchdowns = td;
                Form1.rb_list[Form1.index].Fumbles = f;
                Form1.rb_list[Form1.index].RushingRating = rr;
                pos = "Running Back";
                string input = pos + " " + player[0] + " " + player[1] + " " + c + " " + ry + " " + td + " " + f + " " + rr;
                int count = 0;
                string line;
                string[] str;
                try
                {
                    StreamReader inputFile;
                    inputFile = File.OpenText("stats.txt");
                    while (!inputFile.EndOfStream)
                    {
                        line = inputFile.ReadLine();
                        if (line != String.Empty)
                        {
                            str = line.Split(' ');
                            string filePos = str[0] + " " + str[1];
                            if (fileFirst == str[2] && fileLast == str[3] && pos == filePos)
                            {
                                break;
                            }
                            else
                                count++;
                        }
                        else
                            count++;
                    }
                    inputFile.Close();
                    line = File.ReadLines("stats.txt").Skip(count).Take(1).First();
                    var x = File.ReadAllLines("stats.txt");
                    x[count] = input;
                    File.WriteAllLines("stats.txt", x);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show(invalid);
                invalid = "";
            }
        }
    }
    public class RunningBack : FootballPlayer
    {
            private int m_Carries;
            private double m_RushingYards;
            private int m_Touchdowns;
            private int m_Fumbles;
            private double m_RushingRating;

            public int Carries
            {
                get { return m_Carries; }
                set { m_Carries = value; }
            }
            public double RushingYards
            {
                get { return m_RushingYards; }
                set { m_RushingYards = value; }
            }
            public int Touchdowns
            {
                get { return m_Touchdowns; }
                set { m_Touchdowns = value; }
            }
            public int Fumbles
            {
                get { return m_Fumbles; }
                set { m_Fumbles = value; }
            }
            public double RushingRating
            {
                get { return m_RushingRating; }
                set { m_RushingRating = value; }
            }
            public RunningBack(string first, string last, string position, int carries,
                double ry, int td, int fumbles, double rating) : base(first, last, position)
        {
                m_Carries = carries;
                m_RushingYards = ry;
                m_Touchdowns = td;
                m_Fumbles = fumbles;
                m_RushingRating = rating;
            }
        }
    }