﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FootballStatistics
{
    public partial class WR_TE_Info : Form
    {
        string invalid = "";
        string fileFirst;
        string fileLast;
        public WR_TE_Info()
        {
            InitializeComponent();
            position.Text = Form1.position;
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void save_Click(object sender, EventArgs e)
        {
            int n;
            string pos = position.Text;
            if (pos == "Tight End")
                n = checkTEN();
            else
                n = checkWRN();
            int a = checkA();
            int r = checkR(a);
            double ty = checkTY(r);
            int td = checkTD(r);
            int f = checkF(a);
            if (n != -1 && a != -1 && r != -1 && ty != -1 && td != -1 && f != -1)
            {
                string[] player = name.Text.Split();
                double rr = rating(ty, td, r, f, a);
                if (pos == "Tight End")
                {
                    TightEnd_WideRecieve te = new TightEnd_WideRecieve(player[0], player[1], pos, a, r, ty, td, f, rr);
                    Form1.fbte = te;
                    Form1.te_list.Add(Form1.fbte);
                }
                else
                {
                    TightEnd_WideRecieve wr = new TightEnd_WideRecieve(player[0], player[1], pos, a, r, ty, td, f, rr);
                    Form1.fbwr = wr;
                    Form1.wr_list.Add(Form1.fbwr);
                }
                try
                {
                    StreamWriter outputFile;
                    outputFile = File.AppendText("stats.txt");
                    outputFile.WriteLine(pos + ' ' + player[0] + ' ' + player[1] + ' ' + a + ' ' + r + ' ' + ty + ' ' + td + ' ' + f + ' ' + rr);
                    outputFile.Close();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show(invalid);
                invalid = "";
            }
        }
        public int checkWRN()
        {
            if (name.Text == String.Empty)
            {
                invalid += "Please enter a name.\n";
                return -1;
            }
            string[] n = name.Text.Split();
            if (n.Length != 2)
            {
                invalid += "Please enter First and Last name only.\n";
                return -1;
            }
            if (position.Text == "Wide Receiver")
            {
                for (int x = 0; x < Form1.wr_list.Count; x++)
                {
                    string compare = (string)Form1.wr_list[x].First.ToString() + " " + (string)Form1.wr_list[x].Last.ToString();
                    if (compare.Equals(name.Text, StringComparison.InvariantCultureIgnoreCase))
                    {
                        invalid += "There is already a player with this same name.\n";
                        return -1;
                    }
                }
            }
            else
            {
                for (int x = 0; x < Form1.te_list.Count; x++)
                {
                    string compare = (string)Form1.te_list[x].First.ToString() + " " + (string)Form1.te_list[x].Last.ToString();
                    if (compare.Equals(name.Text, StringComparison.InvariantCultureIgnoreCase))
                    {
                        invalid += "There is already a player with this same name.\n";
                        return -1;
                    }
                }
            }
            return 1;
        }
        public int checkN(int i)
        {
            if (name.Text == String.Empty)
            {
                invalid += "Please enter a name.\n";
                return -1;
            }
            string[] n = name.Text.Split();
            if (n.Length != 2)
            {
                invalid += "Please enter First and Last name only.\n";
                return -1;
            }
            if (position.Text == "Tight End")
            {
                for (int x = 0; x < Form1.te_list.Count; x++)
                {
                    if (i != x)
                    {
                        string compare = (string)Form1.te_list[x].First.ToString() + " " + (string)Form1.te_list[x].Last.ToString();
                        if (compare.Equals(name.Text, StringComparison.InvariantCultureIgnoreCase))
                        {
                            invalid += "There is already a player with this same name.\n";
                            return -1;
                        }
                    }
                }
            }
            else
            {
                for (int x = 0; x < Form1.wr_list.Count; x++)
                {
                    if (i != x)
                    {
                        string compare = (string)Form1.wr_list[x].First.ToString() + " " + (string)Form1.wr_list[x].Last.ToString();
                        if (compare.Equals(name.Text, StringComparison.InvariantCultureIgnoreCase))
                        {
                            invalid += "There is already a player with this same name.\n";
                            return -1;
                        }
                    }
                }
            }
            return 1;
        }
        public int checkTEN()
        {
            if (name.Text == String.Empty)
            {
                invalid += "Please enter a name.\n";
                return -1;
            }
            string[] n = name.Text.Split();
            if (n.Length != 2)
            {
                invalid += "Please enter First and Last name only.\n";
                return -1;
            }
            for (int x = 0; x < Form1.te_list.Count; x++)
            {
                string compare = (string)Form1.te_list[x].First.ToString() + " " + (string)Form1.te_list[x].Last.ToString();
                if (compare.Equals(name.Text, StringComparison.InvariantCultureIgnoreCase))
                {
                    invalid += "There is already a player with this same name.\n";
                    return -1;
                }
            }
            return 1;
        }
        public int checkA()
        {
            int a;
            bool check = Int32.TryParse(attempts.Text, out a);
            if (check)
            {
                if (a < 0)
                {
                    invalid += "Please enter a positive number for Attempts.\n";
                    return -1;
                }
                else
                    return a;
            }
            else
            {
                invalid += "Please enter a valid number for Attempts.\n";
                return -1;
            }
        }
        public int checkR(int a)
        {
            int r;
            bool check = Int32.TryParse(receptions.Text, out r);
            if (check)
            {
                if (r < 0)
                {
                    invalid += "Please enter a positive number for Receptions.\n";
                    return -1;
                }
                else if (r > a)
                {
                    invalid += "Cannot have more Receptions than Attempts.\n";
                    return -1;
                }
                else
                    return r;
            }
            else
            {
                invalid += "Please enter a valid number for Receptions.\n";
                return -1;
            }
        }
        public double checkTY(int r)
        {
            double ty;
            bool check = double.TryParse(yards.Text, out ty);
            if (check)
            {
                if (ty < 0)
                {
                    invalid += "Cannot have a negative number of Yards.\n";
                    return -1;
                }
                else if (ty > 0 && r == 0)
                {
                    invalid += "Cannot have any yards if they did not have any receptions.\n";
                    return -1;
                }
                else
                    return ty;
            }
            else
            {
                invalid += "Please enter a valid number for Total Yards.\n";
                return -1;
            }
        }
        public int checkTD(int r)
        {
            int td;
            bool check = Int32.TryParse(touchdowns.Text, out td);
            if (check)
            {
                if (td < 0)
                {
                    invalid += "Cannot have a negative number of touchdowns.\n";
                    return -1;
                }
                else if (td > 0 && r == 0)
                {
                    invalid += "Cannot have any touchdowns if they did not have any receptions.\n";
                    return -1;
                }
                else
                    return td;
            }
            else
            {
                invalid += "Please enter a valid number for Touchdowns.\n";
                return -1;
            }
        }
        public int checkF(int a)
        {
            int f;
            bool check = Int32.TryParse(fumbles.Text, out f);
            if (check)
            {
                if (f < 0)
                {
                    invalid += "Please enter a positive number for Fumbles.\n";
                    return -1;
                }
                else if (f > a)
                {
                    invalid += "Cannot have higher number of fumbles than attempts.\n";
                    return -1;
                }
                else
                    return f;
            }
            else
            {
                invalid += "Please enter a valid number for Fumbles.\n";
                return -1;
            }
        }
        public double rating(double ty, int td, int r, int f, int a)
        {
            double rr = ((5 * ty) + (250 * td) + (200 * r) - (300 * f)) / a;
            return rr;
        }
        public void displayTE()
        {
            string first = (string)Form1.te_list[Form1.index].First.ToString();
            string last = (string)Form1.te_list[Form1.index].Last.ToString();
            string n = first + ' ' + last;
            name.Text = n;
            position.Text = (string)Form1.te_list[Form1.index].position.ToString();
            attempts.Text = (string)Form1.te_list[Form1.index].Attempts.ToString();
            receptions.Text = (string)Form1.te_list[Form1.index].Receptions.ToString();
            yards.Text = (string)Form1.te_list[Form1.index].TotalYards.ToString();
            touchdowns.Text = (string)Form1.te_list[Form1.index].Touchdowns.ToString();
            fumbles.Text = (string)Form1.te_list[Form1.index].Fumbles.ToString();
            receptionRating.Text = (string)Form1.te_list[Form1.index].ReceptionRating.ToString();
            name.ReadOnly = true;
            attempts.ReadOnly = true;
            receptions.ReadOnly = true;
            yards.ReadOnly = true;
            touchdowns.ReadOnly = true;
            fumbles.ReadOnly = true;
            save.Visible = false;
        }
        public void displayWR()
        {
            string first = (string)Form1.wr_list[Form1.index].First.ToString();
            string last = (string)Form1.wr_list[Form1.index].Last.ToString();
            string n = first + ' ' + last;
            name.Text = n;
            position.Text = (string)Form1.wr_list[Form1.index].position.ToString();
            attempts.Text = (string)Form1.wr_list[Form1.index].Attempts.ToString();
            receptions.Text = (string)Form1.wr_list[Form1.index].Receptions.ToString();
            yards.Text = (string)Form1.wr_list[Form1.index].TotalYards.ToString();
            touchdowns.Text = (string)Form1.wr_list[Form1.index].Touchdowns.ToString();
            fumbles.Text = (string)Form1.wr_list[Form1.index].Fumbles.ToString();
            receptionRating.Text = (string)Form1.wr_list[Form1.index].ReceptionRating.ToString();
            name.ReadOnly = true;
            attempts.ReadOnly = true;
            receptions.ReadOnly = true;
            yards.ReadOnly = true;
            touchdowns.ReadOnly = true;
            fumbles.ReadOnly = true;
            save.Visible = false;
        }
        public void editTE()
        {
            save.Visible = false;
            saveEdit.Visible = true;
            fileFirst = (string)Form1.te_list[Form1.index].First.ToString();
            fileLast = (string)Form1.te_list[Form1.index].Last.ToString();
            string n = fileFirst + ' ' + fileLast;
            name.Text = n;
            position.Text = (string)Form1.te_list[Form1.index].position.ToString();
            attempts.Text = (string)Form1.te_list[Form1.index].Attempts.ToString();
            receptions.Text = (string)Form1.te_list[Form1.index].Receptions.ToString();
            yards.Text = (string)Form1.te_list[Form1.index].TotalYards.ToString();
            touchdowns.Text = (string)Form1.te_list[Form1.index].Touchdowns.ToString();
            fumbles.Text = (string)Form1.te_list[Form1.index].Fumbles.ToString();
            receptionRating.Text = (string)Form1.te_list[Form1.index].ReceptionRating.ToString();
        }
        public void editWR()
        {
            save.Visible = false;
            saveEdit.Visible = true;
            fileFirst = (string)Form1.wr_list[Form1.index].First.ToString();
            fileLast = (string)Form1.wr_list[Form1.index].Last.ToString();
            string n = fileFirst + ' ' + fileLast;
            name.Text = n;
            position.Text = (string)Form1.wr_list[Form1.index].position.ToString();
            attempts.Text = (string)Form1.wr_list[Form1.index].Attempts.ToString();
            receptions.Text = (string)Form1.wr_list[Form1.index].Receptions.ToString();
            yards.Text = (string)Form1.wr_list[Form1.index].TotalYards.ToString();
            touchdowns.Text = (string)Form1.wr_list[Form1.index].Touchdowns.ToString();
            fumbles.Text = (string)Form1.wr_list[Form1.index].Fumbles.ToString();
            receptionRating.Text = (string)Form1.wr_list[Form1.index].ReceptionRating.ToString();
        }

        private void saveEdit_Click(object sender, EventArgs e)
        {
            int n = checkN(Form1.index);
            string pos = position.Text;
            int a = checkA();
            int r = checkR(a);
            double ty = checkTY(r);
            int td = checkF(r);
            int f = checkF(a);
            if (n != -1 && a != -1 && r != -1 && ty != -1 && td != -1 && f != -1)
            {
                string[] player = name.Text.Split();
                double rr = rating(ty, td, r, f, a);
                if (pos == "Tight End")
                {
                    Form1.te_list[Form1.index].First = player[0];
                    Form1.te_list[Form1.index].Last = player[1];
                    Form1.te_list[Form1.index].Attempts = a;
                    Form1.te_list[Form1.index].Receptions = r;
                    Form1.te_list[Form1.index].TotalYards = ty;
                    Form1.te_list[Form1.index].Touchdowns = td;
                    Form1.te_list[Form1.index].Fumbles = f;
                    Form1.te_list[Form1.index].ReceptionRating = rr;
                }
                else
                {
                    Form1.wr_list[Form1.index].First = player[0];
                    Form1.wr_list[Form1.index].Last = player[1];
                    Form1.wr_list[Form1.index].Attempts = a;
                    Form1.wr_list[Form1.index].Receptions = r;
                    Form1.wr_list[Form1.index].TotalYards = ty;
                    Form1.wr_list[Form1.index].Touchdowns = td;
                    Form1.wr_list[Form1.index].Fumbles = f;
                    Form1.wr_list[Form1.index].ReceptionRating = rr;
                }
                string input = pos + " " + player[0] + " " + player[1] + " " + a + " " + r + " " + ty + " " + td + " " + f + " " + rr;
                int count = 0;
                string line;
                string[] str;
                try
                {
                    StreamReader inputFile;
                    inputFile = File.OpenText("stats.txt");
                    while (!inputFile.EndOfStream)
                    {
                        line = inputFile.ReadLine();
                        if (line != String.Empty)
                        {
                            str = line.Split(' ');
                            string filePos = str[0] + " " + str[1];
                            if (fileFirst == str[2] && fileLast == str[3] && pos == filePos)
                            {
                                break;
                            }
                            else
                                count++;
                        }
                        else
                            count++;
                    }
                    inputFile.Close();
                    line = File.ReadLines("stats.txt").Skip(count).Take(1).First();
                    var x = File.ReadAllLines("stats.txt");
                    x[count] = input;
                    File.WriteAllLines("stats.txt", x);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show(invalid);
                invalid = "";
            }
        }
    }

    public class TightEnd_WideRecieve : FootballPlayer
    {
        private int m_Attempts;
        private int m_Receptions;
        private double m_TotalYards;
        private int m_Touchdowns;
        private int m_Fumbles;
        private double m_ReceptionRating;

        public int Attempts
        {
            get { return m_Attempts; }
            set { m_Attempts = value; }
        }
        public int Receptions
        {
            get { return m_Receptions; }
            set { m_Receptions = value; }
        }
        public double TotalYards
        {
            get { return m_TotalYards; }
            set { m_TotalYards = value; }
        }
        public int Touchdowns
        {
            get { return m_Touchdowns; }
            set { m_Touchdowns = value; }
        }
        public int Fumbles
        {
            get { return m_Fumbles; }
            set { m_Fumbles = value; }
        }
        public double ReceptionRating
        {
            get { return m_ReceptionRating; }
            set { m_ReceptionRating = value; }
        }
        public TightEnd_WideRecieve(string first, string last, string position,
            int a, int r, double ty, int td, int f, double rr) : base(first, last, position)
        {
            m_Attempts = a;
            m_Receptions = r;
            m_TotalYards = ty;
            m_Touchdowns = td;
            m_Fumbles = f;
            m_ReceptionRating = rr;
        }
    }
}