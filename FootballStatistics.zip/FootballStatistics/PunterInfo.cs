﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FootballStatistics
{
    public partial class PunterInfo : Form
    {
        string invalid = "";
        string fileFirst;
        string fileLast;
        public PunterInfo()
        {
            InitializeComponent();
            position.Text = Form1.position;
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void save_Click(object sender, EventArgs e)
        {
            int n = checkN();
            string pos = position.Text;
            int p = checkP();
            double ty = checkTY(p);
            double tyr = checkTYR(p);
            if (n != -1 && p != -1 && ty != -1 && tyr != -1)
            {
                string[] player = name.Text.Split();
                double pr = rating(ty, tyr, p);
                Punts punt = new Punts(player[0], player[1], pos, p, ty, tyr, pr);
                Form1.fbp = punt;
                Form1.p_list.Add(Form1.fbp);
                try
                {
                    StreamWriter outputFile;
                    outputFile = File.AppendText("stats.txt");
                    outputFile.WriteLine(pos + ' ' + player[0] + ' ' + player[1] + ' ' + p + ' ' + ty + ' ' + tyr + ' ' + pr);
                    outputFile.Close();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
                MessageBox.Show(invalid);
        }
        public int checkN()
        {
            if (name.Text == String.Empty)
            {
                invalid += "Please enter a name.\n";
                return -1;
            }
            string[] n = name.Text.Split();
            if (n.Length != 2)
            {
                invalid += "Please enter First and Last name only.\n";
                return -1;
            }
            for (int x = 0; x < Form1.p_list.Count; x++)
            {
                string compare = (string)Form1.p_list[x].First.ToString() + " " + (string)Form1.p_list[x].Last.ToString();
                if (compare.Equals(name.Text, StringComparison.InvariantCultureIgnoreCase))
                {
                    invalid += "There is already a player with this same name.\n";
                    return -1;
                }
            }
            return 1;
        }
        private int checkN(int i)
        {
            if (name.Text == String.Empty)
            {
                invalid += "Please enter a name.\n";
                return -1;
            }
            string[] n = name.Text.Split();
            if (n.Length != 2)
            {
                invalid += "Please enter First and Last name only.\n";
                return -1;
            }
            for (int x = 0; x < Form1.p_list.Count; x++)
            {
                if (i != x)
                {
                    string compare = (string)Form1.p_list[x].First.ToString() + " " + (string)Form1.p_list[x].Last.ToString();
                    if (compare.Equals(name.Text, StringComparison.InvariantCultureIgnoreCase))
                    {
                        invalid += "There is already a player with this same name.\n";
                        return -1;
                    }
                }
            }
            return 1;
        }
        public int checkP()
        {
            int p;
            bool check = Int32.TryParse(punts.Text, out p);
            if (check)
            {
                if (p < 0)
                {
                    invalid += "Please enter a positive number of Punts.\n";
                    return -1;
                }
                else
                    return p;
            }
            else
            {
                invalid += "Please enter a valid number of Punts.\n";
                return -1;
            }
        }
        public double checkTY(int p)
        {
            double ty;
            bool check = double.TryParse(yards.Text, out ty);
            if (check)
            {
                if (ty < 0)
                {
                    invalid += "Please enter a positive number of Total Yards.\n";
                    return -1;
                }
                else if (ty > 0 && p == 0)
                {
                    invalid += "Cannot have a total number of yards if player has never punted.\n";
                    return -1;
                }
                else
                    return ty;
            }
            else
            {
                invalid += "Please enter a valid number for Punts.\n";
                return -1;
            }
        }
        public double checkTYR(int p)
        {
            double tyr;
            bool check = double.TryParse(yardsReturned.Text, out tyr);
            if (check)
            {
                if (tyr < 0)
                {
                    invalid += "Please enter a positive number of Total Yards Returned.\n";
                    return -1;
                }
                else if (tyr > 0 && p == 0)
                {
                    invalid += "Cannot have a total number of returned yards if player has never punted.\n";
                    return -1;
                }
                else
                    return tyr;
            }
            else
            {
                invalid += "Please enter a valid number for Returned Punts.\n";
                return -1;
            }
        }
        public double rating(double ty, double tyr, int p)
        {
            double pr = ((5 * ty) - (2 * tyr)) / p;
            return pr;
        }
        public void displayPunter()
        {
            string first = (string)Form1.p_list[Form1.index].First.ToString();
            string last = (string)Form1.p_list[Form1.index].Last.ToString();
            string n = first + ' ' + last;
            name.Text = n;
            position.Text = (string)Form1.p_list[Form1.index].position.ToString();
            punts.Text = (string)Form1.p_list[Form1.index].Punt.ToString();
            yards.Text = (string)Form1.p_list[Form1.index].TotalYards.ToString();
            yardsReturned.Text = (string)Form1.p_list[Form1.index].ReturningYards.ToString();
            puntRating.Text = (string)Form1.p_list[Form1.index].PuntRating.ToString();
            name.ReadOnly = true;
            punts.ReadOnly = true;
            yards.ReadOnly = true;
            yardsReturned.ReadOnly = true;
            save.Visible = false;
        }

        public void editP()
        {
            save.Visible = false;
            saveEdit.Visible = true;
            fileFirst = (string)Form1.p_list[Form1.index].First.ToString();
            fileLast = (string)Form1.p_list[Form1.index].Last.ToString();
            string n = fileFirst + ' ' + fileLast;
            name.Text = n;
            position.Text = (string)Form1.p_list[Form1.index].position.ToString();
            punts.Text = (string)Form1.p_list[Form1.index].Punt.ToString();
            yards.Text = (string)Form1.p_list[Form1.index].TotalYards.ToString();
            yardsReturned.Text = (string)Form1.p_list[Form1.index].ReturningYards.ToString();
            puntRating.Text = (string)Form1.p_list[Form1.index].PuntRating.ToString();
        }

        private void saveEdit_Click(object sender, EventArgs e)
        {
            int n = checkN(Form1.index);
            string pos = position.Text;
            int p = checkP();
            double ty = checkTY(p);
            double tyr = checkTYR(p);
            if (n != -1 && p != -1 && ty != -1 && tyr != -1)
            {
                string[] player = name.Text.Split();
                double pr = rating(ty, tyr, p);
                Form1.p_list[Form1.index].First = player[0];
                Form1.p_list[Form1.index].Last = player[1];
                Form1.p_list[Form1.index].Punt = p;
                Form1.p_list[Form1.index].TotalYards = ty;
                Form1.p_list[Form1.index].ReturningYards = tyr;
                Form1.p_list[Form1.index].PuntRating = pr;
                pos = "Punter";
                string input = pos + " " + player[0] + " " + player[1] + " " + p + " " + ty + " " + tyr + " " + pr;
                int count = 0;
                string line;
                string[] str;
                try
                {
                    StreamReader inputFile;
                    inputFile = File.OpenText("stats.txt");
                    while (!inputFile.EndOfStream)
                    {
                        line = inputFile.ReadLine();
                        if (line != String.Empty)
                        {
                            str = line.Split(' ');
                            if (fileFirst == str[1] && fileLast == str[2] && pos == str[0])
                            {
                                break;
                            }
                            else
                                count++;
                        }
                        else
                            count++;
                    }
                    inputFile.Close();
                    line = File.ReadLines("stats.txt").Skip(count).Take(1).First();
                    var x = File.ReadAllLines("stats.txt");
                    x[count] = input;
                    File.WriteAllLines("stats.txt", x);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show(invalid);
                invalid = "";
            }
        }
    }

    public class Punts : FootballPlayer
    {
        private int m_Punts;
        private double m_TotalYards;
        private double m_ReturnedYards;
        private double m_PuntRating;

        public int Punt
        {
            get { return m_Punts; }
            set { m_Punts = value; }
        }
        public double TotalYards
        {
            get { return m_TotalYards; }
            set { m_TotalYards = value; }
        }
        public double ReturningYards
        {
            get { return m_ReturnedYards; }
            set { m_ReturnedYards = value; }
        }
        public double PuntRating
        {
            get { return m_PuntRating; }
            set { m_PuntRating = value; }
        }
        public Punts(string first, string last, string position, int p, double ty, double ry, double pr) : base(first, last, position)
        {
            m_Punts = p;
            m_TotalYards = ty;
            m_ReturnedYards = ry;
            m_PuntRating = pr;
        }
    }
}